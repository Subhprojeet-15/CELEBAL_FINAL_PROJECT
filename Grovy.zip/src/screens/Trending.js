import React from 'react'

export default function Trending() {
  return (
    <div  className="screen-container"></div>
  )
}
