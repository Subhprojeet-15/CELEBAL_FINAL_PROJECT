import React from 'react'

export default function Favourites() {
  return (
    <div  className="screen-container"></div>
  )
}
