import React, { useEffect } from 'react'
import "./Sidebar.css";
import SidebarButton from './SidebarButton';
import { useState } from 'react';
import { HiFire } from "react-icons/hi";
import { MdSpaceDashboard, MdFavorite, MdLibraryMusic } from "react-icons/md";
import { FaRegPlayCircle, FaSignOutAlt } from "react-icons/fa";
import apiClient from '../../spotify';
export default function Sidebar() {

    const [image,setImage]=useState("https://upload.wikimedia.org/wikipedia/commons/thumb/a/aa/Mangekyou_Sharingan_Sasuke_%28Eternal%29.svg/450px-Mangekyou_Sharingan_Sasuke_%28Eternal%29.svg.png");

    useEffect(()=>{
        apiClient.get("me").then(response=>{console.log(response)
        setImage(response.data.images[0].url);
        })
    },[])


    return (
    
    <div className="sidebar-container">


        <img src={image}className='profile-image' alt="Profile"></img>


        <div>
            <SidebarButton title="Feed" to="/feed" icon={<MdSpaceDashboard/>} />
            <SidebarButton title="Trending" to="/trending" icon={<HiFire/>} />
            <SidebarButton title="Player" to="/player" icon={<FaRegPlayCircle/>} />
            <SidebarButton title="Favourites" to="/favourites" icon={<MdFavorite/>} />
            <SidebarButton title="Library" to="/" icon={<MdLibraryMusic/>} />
        </div>

        <SidebarButton title="Sign Out" to="" icon={<FaSignOutAlt/>}></SidebarButton>

    </div>)
}
