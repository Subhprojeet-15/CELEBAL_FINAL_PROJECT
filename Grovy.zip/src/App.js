import Home from "./screens/Home";

function App() {
  return (
    <div><Home></Home></div>
  );
}

export default App;
